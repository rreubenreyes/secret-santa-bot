const Bunyan = require('bunyan');
const Discord = require('discord.js');

const { TOKEN, DEBUG_CHANNEL } = process.env;

const logger = Bunyan.createLogger({
    name: 'secret-santa-bot',
    level: 'debug'
});

function getDiscordClient() {
    const discord = new Discord.Client();

    discord.login(TOKEN);

    return new Promise((resolve) => {
        discord.on('ready', () => {
            logger.info('Logged in');

            resolve(discord);
        });
    });
}

exports.handler = async () => {
    const discord = await getDiscordClient();

    logger.info({ channels: discord.channels }, 'Currently handling channels');

    await discord.channels.fetch(DEBUG_CHANNEL)
        .then(channel => {
            channel.send('test');
        });

    discord.destroy();
}
